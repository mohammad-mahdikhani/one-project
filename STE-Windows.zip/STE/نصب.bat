@echo off
chcp 65001 >nul
cd /d "%~dp0"
title نصب استی
set "TARGET=%LOCALAPPDATA%\STE"
echo در حال کپی در %TARGET%
mkdir "%TARGET%" 2>nul
xcopy /E /I /Y "%~dp0*" "%TARGET%" >nul
powershell -NoProfile -Command "$desk=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desk 'استی.lnk')); $s.TargetPath=(Join-Path $env:LOCALAPPDATA 'STE\استی.bat'); $s.WorkingDirectory=(Join-Path $env:LOCALAPPDATA 'STE'); $s.WindowStyle=1; $s.Save()"
echo میانبر روی دسکتاپ ساخته شد.
echo.
echo برای باز کردن اپ، استی را از دسکتاپ بزنید.
start "" "%TARGET%\استی.bat"
