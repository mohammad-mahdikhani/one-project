@echo off
chcp 65001 >nul
cd /d "%~dp0"
title استی
if not exist "runtime\Lib\site-packages\flask" (
  echo نصب اول — چند ثانیه طول می‌کشد...
  runtime\python.exe runtime\get-pip.py --no-warn-script-location -q
  if errorlevel 1 goto fail
  runtime\python.exe -m pip install --no-index --find-links wheels flask openpyxl pypdf -q
  if errorlevel 1 goto fail
)
echo اپ استی باز می‌شود...
start "" "http://127.0.0.1:5055"
runtime\python.exe -m ste
goto end
:fail
echo نصب وابستگی‌ها انجام نشد. دوباره استی.bat را بزنید.
pause
:end
